#ifndef PLUGIN_REGISTRAR_H
#define PLUGIN_REGISTRAR_H

// 包含 infoStruct 的定义
#endif // PLUGIN_REGISTRAR_H
